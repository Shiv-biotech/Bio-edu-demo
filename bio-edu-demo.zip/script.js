function getAnswer() {
    let question = document.getElementById('question').value;
    let answerBox = document.getElementById('answer');
    if(question.trim() === "") {
        answerBox.innerText = "Please type a question.";
    } else {
        answerBox.innerText = "This is a demo answer for: " + question;
    }
}
